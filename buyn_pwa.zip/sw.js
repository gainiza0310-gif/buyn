// Кэштің аты: нұсқаны өзгертсең, ескі кэш жаңарады
const CACHE = "buyn-v1"; // Кэш нұсқасы
// Интернетсіз жұмыс істеуі үшін сақталатын файлдар тізімі
const FILES = ["./", "./index.html", "./manifest.json", "./icons/icon-192.png", "./icons/icon-512.png"]; // Сақталатын файлдар
// Орнатылған кезде файлдарды кэшке жүктеу
self.addEventListener("install", e => { // Орнату оқиғасы
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); // Файлдарды кэшке салу
  self.skipWaiting(); // Жаңа нұсқаны бірден қосу
}); // Орнату аяқталды
// Іске қосылғанда ескі кэштерді өшіру
self.addEventListener("activate", e => { // Іске қосу оқиғасы
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))); // Ескі кэшті тазалау
  self.clients.claim(); // Ашық беттерді бақылауға алу
}); // Іске қосу аяқталды
// Сұраныс келгенде алдымен кэштен іздейді, болмаса интернеттен алады
self.addEventListener("fetch", e => { // Сұраныс оқиғасы
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))); // Кэш немесе желі
}); // Сұраныс аяқталды
